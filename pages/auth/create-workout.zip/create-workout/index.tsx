import Text from "@/components/ui/Text";
import { View } from "@/components/ui/View";
import CreateWorkoutForm from "./components/CreateWorkoutForm";
import { useCreateWorkout } from "@/features/workout";
import MainWorkoutScreen from "./MainWorkoutScreen";
import Modal from "@/components/ui/Modal";
import Button from "@/components/ui/Button";
import { useEffect, useState } from "react";
import { useNavigation } from "expo-router";
import { EventArg, NavigationAction } from "@react-navigation/native";

interface WorkoutPageProps {
    id?: string;
}


const WorkoutPage: React.FC<WorkoutPageProps> = () => {
    return (
        <View>
            <Modal style={{ gap: 8 }} visible={continueModalVisible}>
                <Text h2>קיים אימון</Text>
                <Text subtitle>קיים אימון בתהליך יצירה, האם תרצו להמשיך?</Text>
                <View style={{ gap: 8 }}>
                    <Button onPress={() => setContinueModalVisible(false)}>כן</Button>
                    <Button error onPress={() => { reset(); setContinueModalVisible(false); }}>לא</Button>
                </View>
            </Modal>
            {!workoutName ? (
                <Modal style={{ gap: 8 }}>
                    <Text h1>יצירת אימון חדש</Text>
                    <CreateWorkoutForm />
                </Modal>
            ) : <MainWorkoutScreen />}

            {notSavedModalVisible && <Modal style={{ gap: 8 }} visible>
                <Text h2>לא נשמרו השינויים</Text>
                <Text subtitle>האם תרצו לצאת מהאימון?</Text>
                <View style={{ gap: 8 }}>
                    <Button onPress={() => navigation.dispatch(leaveRouteAction)}>כן</Button>
                    <Button error onPress={() => setNotSavedModalVisible(false)}>לא</Button>
                </View>
            </Modal>}
        </View>
    );
}

export default WorkoutPage;
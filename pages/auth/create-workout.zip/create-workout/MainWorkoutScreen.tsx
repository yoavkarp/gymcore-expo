import Text from "@/components/ui/Text";
import { View } from "@/components/ui/View";
import TextInput from "@/components/ui/TextInput";
import Label from "@/components/ui/Label";
import { Controller } from "react-hook-form";
import Select from "@/components/ui/Select";
import React from "react";
import ExerciseList from "./components/ExerciseList";
import { ExerciseType, useUpdateWorkoutMutation, Workout } from "@/graphql";
import StrengthExerciseForm from "./components/StrengthExerciseForm";
import Button from "@/components/ui/Button";
import { UpdateWorkoutFormInput, useUpdateWorkoutForm } from "./hooks/useUpdateWorkoutForm";

const exerciseTypes = [{
    title: "קרדיו",
    value: "CARDIO"
}, {
    title: "כוח",
    value: "STRENGTH"
}];

interface MainWorkoutScreenProps {
    workout: Workout;
}

const MainWorkoutScreen: React.FC<MainWorkoutScreenProps> = ({ workout }) => {

    const { control, formState: { isDirty, dirtyFields }, handleSubmit, reset } = useUpdateWorkoutForm({
        defaultValues: {
            name: workout.name,
            notes: workout.notes,
        }
    });
    const [updateWorkout] = useUpdateWorkoutMutation({
        update(cache, { data }, { variables }) {
            cache.modify({
                id: cache.identify({ __typename: data?.__typename, id: variables?.id }),
                fields: {
                    name() {
                        return data?.updateWorkout?.name;
                    },
                    notes() {
                        return data?.updateWorkout?.notes;
                    }
                }
            })
        },
        onCompleted(data) {
            reset({
                name: data.updateWorkout?.name,
                notes: data.updateWorkout?.notes
            })
        }
    });

    const onSubmitUpdateWorkout = async (data: UpdateWorkoutFormInput) => {
        await updateWorkout({
            variables: {
                id: workout.id,
                input: Object.keys(dirtyFields).reduce<any>((acc, key) => {
                    acc[key] = data[key as keyof UpdateWorkoutFormInput];
                    return acc;
                }, {})
            }
        })
    }

    return (
        <View style={{ padding: 8 }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <Text h1>מסך יצירת אימון</Text>
            </View>

            <View style={{ flexDirection: 'row', gap: 20 }}>
                <View style={{ flexBasis: "50%", gap: 20 }}>
                    <Controller control={control} name="name"
                        render={({ field: { onChange, onBlur, value }, fieldState: { error, isDirty } }) => (
                            <View style={{ alignSelf: 'flex-start' }}>
                                <Label>שם האימון</Label>
                                <TextInput style={{ width: 300, textAlign: 'center' }} error={Boolean(error)} onChangeText={onChange} onBlur={onBlur} value={value} />
                                {isDirty && <Button onPress={handleSubmit(onSubmitUpdateWorkout)}>שמור</Button>}
                                {error && <Text error>{error.message}</Text>}
                            </View>
                        )}
                    />
                    {/* <View>
                        <Label>רשימת תרגילים</Label>
                        <ExerciseList onChangeSelect={setSelectedExerciseId} />
                        <Button onPress={submitForm(currentTrainer?.id!)}>סיום</Button>
                        <Text>
                            {JSON.stringify(errors, null, 2)}
                        </Text>
                    </View>
                </View>
                {selectedExercise && <View style={{ flexBasis: "48%", paddingTop: 10 }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                        <Text h1>{selectedExercise?.name}</Text>
                        <Select
                            items={exerciseTypes}
                            defaultValue="strength"
                            onChangeValue={({ value }) => setValue(`exercises.${exercises.indexOf(selectedExercise)}.type`, value as ExerciseType)}
                        />
                    </View>
                    {selectedExercise.type === ExerciseType.Strength && <StrengthExerciseForm selectedExerciseId={selectedExerciseId} />}
                </View>} */}
                </View>
            </View>

        </View>
    );
}

export default MainWorkoutScreen;